/**
   A program that allows users to edit a scene composed of items.
*/
public class SceneEditor
{
   /**
     A program that allows users to edit a scene composed of items.
     @param args unused
   */
   public static void main(String[] args)
   {
      SceneFrame sceneFrame = new SceneFrame();
      sceneFrame.setVisible(true);
   }
}


